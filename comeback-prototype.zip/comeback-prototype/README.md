# COMEBACK – prototype

**Det skal være enkelt å begynne igjen – sammen med et lag.**

COMEBACK er et seksukers program for treningssentermedlemmer som har falt ut av treningsrutinene sine. Medlemmene settes sammen i små lag ut fra når de faktisk har tid, trener fast med en PT, og har en plan B som teller når hverdagen kommer i veien.

Dette er en klikkbar prototype laget i faget Design Thinking (DTH3100) ved Høyskolen Kristiania. Lagkameratene, PT-en og innleggene er oppdiktet.

## Åpne prototypen

**[Åpne COMEBACK-appen](https://BRUKERNAVN.github.io/comeback-prototype/)**

Den er laget for mobil. Åpne lenken på telefonen, gjerne i Safari eller Chrome.

## Slik tester du

Gå gjennom appen som om du er et medlem som har falt av treningen. Prøv disse oppgavene:

1. **Svar på invitasjonen** og gå gjennom oppstartsmøtet.
2. **Fyll ut ukekartet** med din egen uke, og se hvilket lag du havner på.
3. **Lag avtalen din** – velg antall økter og en plan B.
4. **Si at du ikke rekker en lagøkt**, og gjennomfør en plan B-økt hjemme.
5. **Legg inn en ekstra økt**, og bli med på en økt noen andre på laget har lagt ut.
6. **Gi heia** til noen på laget.

**Tips:**
- Under **Meg → Testmodus** kan du velge uke og dag selv, for eksempel en lagdag, så du slipper å vente.
- **Meg → Testmodus → Start prototypen på nytt** nullstiller alt.
- Det du gjør lagres bare på din egen telefon. Andre ser ikke det du legger inn.

## Gi tilbakemelding

Gå til **[Issues](../../issues/new/choose)** og velg **«Tilbakemelding på prototypen»**. Fyll ut det du har lyst til – korte svar er helt greit.

Vi er særlig nysgjerrige på:
- Kjennes laget og oppfølgingen som **støtte eller press**?
- Er det tydelig hva **plan B** er, og hvorfor den teller?
- Hva ville fått deg til å **slutte** i uke 3?
