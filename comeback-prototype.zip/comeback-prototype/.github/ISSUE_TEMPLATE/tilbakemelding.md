---
name: Tilbakemelding på prototypen
about: Si hva du synes etter at du har testet COMEBACK-appen
title: "Tilbakemelding fra [navn]"
labels: tilbakemelding
---

**Hvilken telefon/nettleser brukte du?**


**Hva fungerte bra?**


**Hva var forvirrende eller vanskelig?**


**Kjentes laget og oppfølgingen som støtte eller press? (1 = bare press, 5 = bare støtte)**


**Var det tydelig hva plan B er og hvorfor den teller?**


**Ville du meldt deg på COMEBACK? (1–5) Hvorfor/hvorfor ikke?**


**Hva ville fått deg til å slutte i uke 3?**


**Fant du noe som ikke virket? (feil, knapper som ikke gjør noe, rar tekst)**


**Noe annet?**

